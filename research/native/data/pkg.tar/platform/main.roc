platform ""
	requires {} { handle! : Str => Str }
	exposes [Wait, Js, Io]
	packages {}
	provides { "roc_handle": handle_for_host! }
	hosted { "roc_wait": Wait.wait!, "roc_await": Host.await!, "roc_call": Host.call!, "roc_native": Host.native! }
	targets: {
		inputs_dir: "targets/",
		wasm32: {
			inputs: ["host.wasm", app],
			output: Shared,
			# The production exports (PLAN.md 7a). bench/platform/main.roc is the same header with more exports: bench/exports-test.mjs checks it.
			# Stack: 1 MB, read by hostlib/canary.zig from the linker. Memory: sized by the linker. No maximum (PLAN.md M5).
			initial_stack_size: 1048576,
			minimum_memory: 0,
			exports: ["init", "handle", "task_abort", "task_cancel", "task_slots", "js_alloc", "res_free", "stack_first", "set_free_mark", "set_grow_step", "check_heap", "log_ptr", "log_len", "log_clear", "heap_used", "heap_bytes", "live_bytes", "live_peak", "reclaim_walks", "reclaim_bytes", "leaked_at_end", "idle_resets", "idle_reset_bytes", "alarms", "sum_checks", "double_frees", "dealloc_miss", "idle_reset", "trap_cause", "set_sum", "set_suspect", "__instance_signal", "__instance_terminated"],
		},
	}

import Wait
import Js
import Io
import Host

handle_for_host! : Str => Str
handle_for_host! = |req| handle!(req)
